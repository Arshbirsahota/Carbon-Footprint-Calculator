/* ==========================================================
   Network Footprint — site behaviour and carbon calculator
   ========================================================== */

document.documentElement.classList.add('js');

/* ---------- Constants (see the Sources section of index.html) ---------- */

// Typical data use per hour of each activity, in GB.
// Video rates follow Netflix's published figures; the others are typical averages.
const RATES_GB_PER_HOUR = {
  social: 0.7,
  calls: 1.2,
  music: 0.15
};

const DAYS_PER_MONTH = 30;
const KG_CO2_PER_KM_CAR = 0.393 / 1.609;   // EPA: 393 g CO2 per mile, typical passenger vehicle
const KG_CO2_PER_TREE_10YR = 60;           // EPA: 0.060 t CO2 per urban tree seedling grown for 10 years
const SD_VIDEO_GB_PER_HOUR = 1;

/* ---------- Helpers ---------- */

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

function readNumber(input) {
  const value = parseFloat(input.value);
  return Number.isFinite(value) && value >= 0 ? value : 0;
}

function formatNumber(value, maxDecimals = 1) {
  const decimals = value >= 100 ? 0 : value >= 10 ? Math.min(1, maxDecimals) : maxDecimals;
  return value.toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals
  });
}

/* ---------- Header: sticky border, mobile menu, active section ---------- */

function initHeader() {
  const header = $('.site-header');
  const toggle = $('.nav-toggle');
  const nav = $('#site-nav');

  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  const closeMenu = () => {
    toggle.setAttribute('aria-expanded', 'false');
    nav.classList.remove('is-open');
  };

  toggle.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    nav.classList.toggle('is-open', open);
  });

  $$('a', nav).forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && nav.classList.contains('is-open')) {
      closeMenu();
      toggle.focus();
    }
  });

  // Highlight the nav link for the section currently in view
  if (!('IntersectionObserver' in window)) return;
  const links = new Map($$('a[href^="#"]', nav).map((a) => [a.getAttribute('href').slice(1), a]));
  const sections = Array.from(links.keys()).map((id) => document.getElementById(id)).filter(Boolean);

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      links.forEach((a) => a.classList.remove('is-active'));
      const active = links.get(entry.target.id);
      if (active) active.classList.add('is-active');
    });
  }, { rootMargin: '-45% 0px -50% 0px' });

  sections.forEach((section) => observer.observe(section));
}

/* ---------- Energy bar: animate once when it scrolls into view ---------- */

function initEnergyBar() {
  const bar = $('.energy-bar');
  if (!bar) return;
  if (!('IntersectionObserver' in window)) {
    bar.classList.add('is-visible');
    return;
  }
  const observer = new IntersectionObserver((entries) => {
    if (entries.some((entry) => entry.isIntersecting)) {
      bar.classList.add('is-visible');
      observer.disconnect();
    }
  }, { threshold: 0.4 });
  observer.observe(bar);
}

/* ---------- Calculator ---------- */

const calc = {
  mode: 'activity',
  els: {}
};

function initCalculator() {
  const form = $('#calc-form');
  if (!form) return;

  calc.els = {
    tabs: $$('[role="tab"]', form),
    videoQuality: $('#video-quality'),
    video: $('#hours-video'),
    social: $('#hours-social'),
    calls: $('#hours-calls'),
    music: $('#hours-music'),
    downloads: $('#gb-downloads'),
    total: $('#data-usage'),
    totalError: $('#data-usage-error'),
    grid: $('#grid'),
    gridCustom: $('#grid-custom'),
    gridCustomWrap: $('.custom-grid'),
    scope: $('#scope'),
    year: $('#result-year'),
    month: $('#result-month'),
    gb: $('#result-gb'),
    breakdown: $('#breakdown'),
    breakdownList: $('#breakdown-list'),
    km: $('#eq-km'),
    trees: $('#eq-trees'),
    insight: $('#insight')
  };

  form.addEventListener('submit', (event) => event.preventDefault());

  // Keep each slider and number box in sync
  $$('input[type="range"]', form).forEach((range) => {
    const number = document.getElementById(range.id.replace('-range', ''));
    const sync = (source, target) => {
      target.value = source.value;
      paintRange(range);
      calculateImpact();
    };
    range.addEventListener('input', () => sync(range, number));
    number.addEventListener('input', () => {
      range.value = Math.min(readNumber(number), Number(range.max));
      paintRange(range);
      calculateImpact();
    });
    paintRange(range);
  });

  [calc.els.videoQuality, calc.els.scope, calc.els.gridCustom, calc.els.total].forEach((el) => {
    el.addEventListener('input', calculateImpact);
  });

  calc.els.grid.addEventListener('change', () => {
    const custom = calc.els.grid.value === 'custom';
    calc.els.gridCustomWrap.hidden = !custom;
    if (custom) calc.els.gridCustom.focus();
    calculateImpact();
  });

  initTabs();
  calculateImpact();
}

function paintRange(range) {
  const pct = ((range.value - range.min) / (range.max - range.min)) * 100;
  range.style.setProperty('--fill', `${pct}%`);
}

function initTabs() {
  const tabs = calc.els.tabs;

  const select = (tab, focus = false) => {
    tabs.forEach((t) => {
      const selected = t === tab;
      t.setAttribute('aria-selected', String(selected));
      t.tabIndex = selected ? 0 : -1;
      document.getElementById(t.getAttribute('aria-controls')).hidden = !selected;
    });
    if (focus) tab.focus();
    calc.mode = tab.id === 'tab-total' ? 'total' : 'activity';
    calculateImpact();
  };

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => select(tab));
    tab.addEventListener('keydown', (event) => {
      if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
      event.preventDefault();
      const step = event.key === 'ArrowRight' ? 1 : -1;
      select(tabs[(index + step + tabs.length) % tabs.length], true);
    });
  });
}

function getGridIntensity() {
  const { grid, gridCustom } = calc.els;
  const grams = grid.value === 'custom' ? readNumber(gridCustom) : Number(grid.value);
  return grams / 1000; // kg CO2 per kWh
}

/** Monthly data use per activity, in GB. */
function getActivityData() {
  const e = calc.els;
  const videoRate = Number(e.videoQuality.value);
  return [
    { key: 'video', label: 'Video streaming', gb: readNumber(e.video) * videoRate * DAYS_PER_MONTH },
    { key: 'social', label: 'Social media', gb: readNumber(e.social) * RATES_GB_PER_HOUR.social * DAYS_PER_MONTH },
    { key: 'calls', label: 'Video calls', gb: readNumber(e.calls) * RATES_GB_PER_HOUR.calls * DAYS_PER_MONTH },
    { key: 'music', label: 'Music', gb: readNumber(e.music) * RATES_GB_PER_HOUR.music * DAYS_PER_MONTH },
    { key: 'downloads', label: 'Downloads and backups', gb: readNumber(e.downloads) }
  ];
}

function calculateImpact() {
  const e = calc.els;
  if (!e.year) return;

  const kWhPerGB = Number(e.scope.value);
  const kgPerKWh = getGridIntensity();
  const kgPerGB = kWhPerGB * kgPerKWh;

  let items;
  if (calc.mode === 'total') {
    const raw = e.total.value.trim();
    const valid = raw === '' || (Number.isFinite(Number(raw)) && Number(raw) >= 0);
    e.total.setAttribute('aria-invalid', String(!valid));
    e.totalError.hidden = valid;
    items = [{ key: 'total', label: 'All data', gb: valid ? readNumber(e.total) : 0 }];
  } else {
    items = getActivityData();
  }

  const monthlyGB = items.reduce((sum, item) => sum + item.gb, 0);
  const monthlyKg = monthlyGB * kgPerGB;
  const yearlyKg = monthlyKg * 12;

  e.year.textContent = formatNumber(yearlyKg);
  e.month.textContent = formatNumber(monthlyKg);
  e.gb.textContent = formatNumber(monthlyGB, 0);
  e.km.textContent = formatNumber(yearlyKg / KG_CO2_PER_KM_CAR, 0);
  e.trees.textContent = formatNumber(yearlyKg / KG_CO2_PER_TREE_10YR, 1);

  renderBreakdown(items, monthlyGB, kgPerGB);
  renderInsight(kgPerGB);
}

function renderBreakdown(items, monthlyGB, kgPerGB) {
  const { breakdown, breakdownList } = calc.els;
  const show = calc.mode === 'activity' && monthlyGB > 0;
  breakdown.hidden = !show;
  if (!show) return;

  const sorted = items.filter((item) => item.gb > 0).sort((a, b) => b.gb - a.gb);
  breakdownList.innerHTML = '';

  sorted.forEach((item) => {
    const share = (item.gb / monthlyGB) * 100;
    const li = document.createElement('li');
    li.innerHTML = `
      <span class="b-label"></span>
      <span class="b-value"></span>
      <span class="b-track" aria-hidden="true"><span class="b-fill"></span></span>`;
    li.querySelector('.b-label').textContent = item.label;
    li.querySelector('.b-value').textContent =
      `${formatNumber(item.gb * kgPerGB * 12)} kg (${Math.round(share)}%)`;
    li.querySelector('.b-fill').style.setProperty('--pct', `${share}%`);
    breakdownList.appendChild(li);
  });
}

/** Suggest the single most useful change: lowering video quality. */
function renderInsight(kgPerGB) {
  const { insight, videoQuality, video } = calc.els;
  const rate = Number(videoQuality.value);
  const hours = readNumber(video);

  if (calc.mode !== 'activity' || rate <= SD_VIDEO_GB_PER_HOUR || hours === 0) {
    insight.hidden = true;
    return;
  }

  const savedGB = hours * (rate - SD_VIDEO_GB_PER_HOUR) * DAYS_PER_MONTH * 12;
  const savedKg = savedGB * kgPerGB;
  const quality = rate >= 7 ? '4K' : 'HD';

  insight.hidden = false;
  insight.textContent =
    `Watching in standard definition instead of ${quality} on a phone would save about ` +
    `${formatNumber(savedKg)} kg of CO₂ a year, with little visible difference on a small screen.`;
}

/* ---------- Footer year ---------- */

function initYear() {
  const year = $('#year');
  if (year) year.textContent = String(new Date().getFullYear());
}

/* ---------- Start ---------- */

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initEnergyBar();
  initCalculator();
  initYear();
});
