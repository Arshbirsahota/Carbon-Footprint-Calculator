# Environmental Impact of Network Traffic

A responsive, single-page website explaining how much energy and carbon the internet uses: where that energy goes, the latest figures, how to cut the impact, and a calculator for estimating the footprint of your own data use.

## Features

- **The journey of a gigabyte**: a breakdown of the ~0.30 kWh behind each gigabyte across data centres, networks and user devices, split into running and manufacturing energy.
- **Environmental impact**: energy demand, carbon emissions and e-waste, plus the technical and economic effects of heavy traffic (performance, security, cost, user experience, storage).
- **Key figures** with linked sources (IEA, Ember, Sandvine, Global E-waste Monitor, and others).
- **Practical solutions** for everyday users and for people who build websites and apps.
- **Carbon footprint calculator**
  - Estimate by daily activity (video, social media, calls, music, downloads) or by total GB per month
  - Choose a grid (India, world average, or a custom value) and what to count (networks only, running energy, or running plus manufacturing)
  - Per-activity breakdown, real-world comparisons, and a personalised tip
- Accessible: keyboard navigation, skip link, visible focus states, ARIA tabs and live results, reduced-motion support.
- Responsive from 320px phones to wide desktops, and works without any build step or framework.

## Project structure

```
├── index.html        Page content and structure
├── style.css         Design tokens, layout and responsive styles
├── script.js         Navigation behaviour and the carbon calculator
├── assets/
│   ├── banner.jpg    Hero image (optimised)
│   ├── banner.webp   Hero image, WebP version for modern browsers
│   └── favicon.svg   Site icon
├── LICENSE
└── README.md
```

## Running locally

No installation needed. Open `index.html` in a browser, or serve the folder:

```bash
python -m http.server 8000
# then visit http://localhost:8000
```

To publish on GitHub Pages: push the repository, then go to **Settings → Pages** and deploy from the `main` branch root.

## How the calculator works

```
CO₂ (kg) = data used (GB) × energy per GB (kWh/GB) × grid carbon intensity (kg CO₂/kWh)
```

| Assumption | Value | Source |
| --- | --- | --- |
| Networks only | 0.059 kWh/GB | Sustainable Web Design Model v4 |
| Running energy (data centres, networks, devices) | 0.194 kWh/GB | Sustainable Web Design Model v4 |
| Running plus manufacturing | 0.300 kWh/GB | Sustainable Web Design Model v4 |
| India grid, 2024 | 708 g CO₂/kWh | Ember, Global Electricity Review 2025 |
| World average grid, 2024 | 473 g CO₂/kWh | Ember, Global Electricity Review 2025 |
| Video streaming | 1 / 3 / 7 GB per hour (SD / HD / 4K) | Netflix |
| Car comparison | 393 g CO₂ per mile | US EPA |
| Tree comparison | 60 kg CO₂ per seedling over 10 years | US EPA |

Results are estimates. Network energy doesn't rise in strict proportion to data volume, so per-gigabyte models tend to give higher figures for video than bottom-up studies (the IEA estimates about 36 g CO₂ per hour of streaming). The constants are at the top of `script.js` if you want to adjust them.

## Sources

1. International Energy Agency (2025). [Energy and AI](https://www.iea.org/reports/energy-and-ai/executive-summary)
2. Sustainable Web Design (2024). [Estimating digital emissions](https://sustainablewebdesign.org/estimating-digital-emissions/)
3. Ember (2025). [Global Electricity Review 2025](https://ember-energy.org/latest-insights/global-electricity-review-2025/global-electricity-trends/)
4. ITU and UNITAR (2024). [Global E-waste Monitor 2024](https://www.itu.int/hub/2024/04/the-world-generated-62-million-tonnes-of-electronic-waste-in-just-one-year-and-recycled-way-too-little-un-agencies-warn/)
5. Sandvine (2023). [Global Internet Phenomena Report](https://www.applogicnetworks.com/press-releases/sandvines-2023-global-internet-phenomena-report-shows-24-jump-in-video-traffic-with-netflix-volume-overtaking-youtube)
6. Freitag, C. et al. (2021). [The real climate and transformative impact of ICT](https://www.cell.com/patterns/fulltext/S2666-3899(21)00188-4), *Patterns*
7. International Energy Agency (2020). [The carbon footprint of streaming video](https://www.iea.org/commentaries/the-carbon-footprint-of-streaming-video-fact-checking-the-headlines)
8. US EPA. [Greenhouse gas equivalencies](https://www.epa.gov/energy/greenhouse-gas-equivalencies-calculator-calculations-and-references)

## Creator

Arshbir Singh

## License

Released under the [GNU General Public License v3.0](LICENSE).
